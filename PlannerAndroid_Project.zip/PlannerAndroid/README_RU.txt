Планировщик — Android WebView-проект

Это исходный проект приложения, упаковывающий ваш planner.html в Android-приложение.
Готовый APK в этом архиве не собран.

Как получить APK:
1. Установите Android Studio на компьютер.
2. Откройте в Android Studio папку PlannerAndroid.
3. Дождитесь синхронизации Gradle.
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK обычно появится в app/build/outputs/apk/debug/app-debug.apk.

Данные задач, планов и заметок сохраняются через localStorage WebView на этом устройстве.
Для загрузки Google Fonts и запроса разрешения на уведомления может понадобиться интернет.
Примечание: напоминания в исходном HTML реализованы JavaScript-таймером; системные уведомления Android могут работать не так, как в браузере.
